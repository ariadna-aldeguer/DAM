/* *****************************************************
//    INS JOAN D'AUSTRIA
//	CFGS DAW
//	M2: Bases de dades. UF2: Llenguatge SQL
//	PRÀCTICA UF2. FASE 
//	AUTOR: Daniel Mármol Fernández
//	DATA: 22/01/2020
****************************************************** */

/* Fase 1 */
CREATE TABLE EQUIPO(
	nombre varchar2(20) not null,
	ciudad varchar2(20) not null,
	conferencia char(4) not null,
	division char(9) not null
);

CREATE TABLE JUGADOR(
    codigo number(5),
	nombre varchar2(30) not null,
	procedencia varchar2(20),
	altura varchar2(4),
	peso number(3),
	posicion varchar2(3),
	nombre_equipo varchar2(20)
);

CREATE TABLE ESTADISTICAS(
    codigo number(5),
    temporada varchar2(5),
	puntos_por_partido number(2,1),
	asistencias_por_partido number(2,1),
	tapones_por_partido number(2,1),
	rebotes_por_partido number(2,1)
);

CREATE TABLE PARTIDO(
	equipo_local varchar2(20) not null,
	equipo_visitante varchar2(20) not null,
	puntos_local number(3),
	puntos_visitante number(3),
	temporada varchar2(5)
);

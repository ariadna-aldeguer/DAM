/* *****************************************************
//    INS JOAN D'AUSTRIA
//	CFGS DAW
//	M2: Bases de dades. UF2: Llenguatge SQL
//	PRÀCTICA UF2. FASE
//	AUTOR: Pedro Martínez Garcia
//	DATA: 23/01/2020
****************************************************** */

/* Pregunta 1 */
DROP TABLE EQUIPO;
DROP TABLE JUGADOR;
DROP TABLE ESTADISTICAS;
DROP TABLE PARTIDO;


CREATE TABLE EQUIPO(
    Nombre varchar2(20) primary key not null;
    Ciudad varchar2(20) not NULL;
    Conferencia varchar2(4) check ('East', 'West') not NULL;
    Division varchar2(9) check ('Atlantic', 'Central', 'SouthEast', 'NorthWest', 'Pacific' , 'SouthWest') not null
);

CREATE TABLE JUGADOR(
    Codigo number(3,0) primary key not null ;/* 15 jugadors màxims per equip 30 equips 450<999*/
    Nombre varchar2(30) not null;
    Procedencia varchar2(20);
    Altura char (1) + '-' + char (2) ; /*||concatenació de strings */
    Peso number (3) check (Peso >= 130 and Peso <= 400); /*peus - polzades*/
    Posicion char (1) + '-' + char (1) check (posicion = G or posicion = F or posicion = C );/* G = guard, F = forward , C= pivot poden ocupar dos posicions diferents separat per - */
    Nombre_Equipo varchar2(20) reference EQUIPO not null ON DELETE RESTRICT
);

CREATE TABLE ESTADISTICAS(
    Codigo_Jugador number(3,0) foreign key reference JUGADOR not null;
    Temporada number(2,0) +'/'+ number (2,0) not null;
    Puntos_por_partido number (3,1) default 0 check (Puntos_por_partido >= 0) ;
    Asistencias_por_partido number(3,1) default 0 check ( Asistencias_por_partido >= 0);
    Tapones_por_partido number (3,1) default 0 check (Tapones_por_partido >= 0);
    Rebotes_por_partido number (3,1)  default 0 check (Rebotes_por_partido >= 0) ON DELETE CASCADE
);

CREATE TABLE PARTIDO(
    Codigo number (1,0) UNIQUE not null;
    Equipo_local varchar2(20) reference EQUIPO not null;
    Equipo_visitante varchar2(20) reference EQUIPO not null;
    Puntos_local number(3,0);
    Puntos_visitante number (3,0);
    Temporada_Estadisticas number(2,0) + '/' + number (2,0) reference ESTADISTICAS not null ON DELETE RESTRICT
);

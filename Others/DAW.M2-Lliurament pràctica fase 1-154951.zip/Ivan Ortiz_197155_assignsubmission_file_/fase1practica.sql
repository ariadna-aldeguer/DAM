/* *****************************************************
//    INS JOAN D'AUSTRIA
//	CFGS DAW
//	M2: Bases de dades. UF2: Llenguatge SQL
//	PRÀCTICA UF2. FASE 1
//	AUTOR: Ivan Ortiz
//	DATA: 20/01/2020
****************************************************** */

/* Pregunta 1 */

CREATE TABLE EQUIPO(
	nombre varchar2(20) NOT NULL, 
	ciudad varchar2(20) NOT NULL, 
	conferencia varchar2(25) NOT NULL, 
	division varchar2(25) NOT NULL
);


CREATE TABLE JUGADOR(
	codigo number NOT NULL,
	nombre varchar2(20),  
	procedencia varchar2(30), 
	altura number(4), 
	peso number(3), 
	posicion char(1)
);

CREATE TABLE ESTADISTICA(
	puntos_por_partido number(3,1) DEFAULT 0, 
	asistencias_por_partido number(4,1) DEFAULT 0, 
	tapones_por_partido number(4) DEFAULT 0, 
	rebotes_por_partido number(4) DEFAULT 0
);

CREATE TABLE PARTIDO(
	equipo_local varchar2(20), 
	equipo_visitante varchar2(20), 
	puntos_local number(3), 
	puntos_visitante number(4), 
	temporada number(4)
);

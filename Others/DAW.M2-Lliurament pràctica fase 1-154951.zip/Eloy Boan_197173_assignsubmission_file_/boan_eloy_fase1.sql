/* *****************************************************
//    INS JOAN D'AUSTRIA
//	CFGS DAW
//	M2: Bases de dades. UF2: Llenguatge SQL
//	PRÀCTICA UF2. FASE 
//	AUTOR: Eloy Boán López
//	DATA: 20/01/2020
****************************************************** */

/* Pregunta 1 */
CREATE TABLE EQUIPO(
	DIVISION varchar2(9) NOT NULL,
	NOMBRE varchar2(20) NOT NULL,
	CIUDAD varchar2(20) NOT NULL,
	CONFERENCIA char(4) NOT NULL
);
CREATE TABLE PARTIDO(
	CODIGO number(2) NOT NULL,
	EQUIPO_LOCAL varchar2(20) NOT NULL,
	EQUIPO_VISITANTE varchar2(20) NOT NULL,
	PUNTOS_LOCAL number(3),
	PUNTOS_VISITANTE number(3),
	TEMPORADA number(4) NOT NULL
);
CREATE TABLE JUGADOR(
	CODIGO number(2) NOT NULL,
	NOMBRE varchar2(30) NOT NULL,
	PROCEDENCIA varchar2(20),
	ALTURA number(4),
	PESO number(3),
	POSICION char(1) NOT NULL
);
CREATE TABLE ESTADÍSITCAS(
	TEMPORADA number(4) NOT NULL,
	PUNTOS_POR_PARTIDO number (2,1) DEFAULT 0,
	ASISTENCIAS_POR_PARTIDO number (2,1) DEFAULT 0,
	TAPONES_POR_PARTIDO number (2,1) DEFAULT 0,
	REBOTES_POR_PARTIDO number (2,1) DEFAULT 0
);
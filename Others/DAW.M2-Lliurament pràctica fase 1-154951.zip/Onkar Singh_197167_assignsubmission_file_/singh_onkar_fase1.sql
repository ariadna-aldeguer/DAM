/* *****************************************************
//    INS JOAN D'AUSTRIA
//	CFGS DAW
//	M2: Bases de dades. UF2: Llenguatge SQL
//	PRÀCTICA UF2. FASE 
//	AUTOR: ONKAR SINGH KAUR
//	DATA: 18/1/2020
****************************************************** */

/* Pregunta 1 */
DROP TABLE Equipo;
DROP TABLE Jugador;
DROP TABLE Estadisticas;
DROP TABLE Partido;

CREATE TABLE Equipo (
	nombre varchar(20) NOT NULL,
	ciudad varchar (20) NOT NULL,
	conferencia char (4) NOT NULL,
	division varchar(9) NOT NULL
);

CREATE TABLE Jugador (
	codigo number(3) NOT NULL,
	nombre varchar(20) NOT NULL,
	procedencia varchar(20),
	altura char(4),
	peso number(3),
	posicion char(5) NOT NULL,
	nombre_equipo varchar(20) NOT NULL
);

CREATE TABLE Estadisticas (
	codigo number(3) NOT NULL,
	temporada char(5) NOT NULL,
	puntos_por_partido number(2,1) DEFAULT 0,
	asistencias_por_partido number(2,1) DEFAULT 0,
	tapones_por_partido number(2,1) DEFAULT 0,
	rebotes_por_partido number(2,1) DEFAULT 0
);

CREATE TABLE Partido (
	codigo number(2) NOT NULL,
	equipo_local varchar2(20) NOT NULL,
	equipo_visitante varchar2(20) NOT NULL,
	puntos_local number(3),
	puntos_visitantes number(3),
	temporada char(5) NOT NULL
);

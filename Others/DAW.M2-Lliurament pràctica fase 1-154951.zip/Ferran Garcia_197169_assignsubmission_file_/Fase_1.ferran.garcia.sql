/* *****************************************************
//    INS JOAN D'AUSTRIA
//	CFGS DAW
//	M2: Bases de dades. UF2: Llenguatge SQL
//	PRÀCTICA UF2. FASE 
//	AUTOR: FERRAN GARCIA MONZONIS
//	DATA: 20/01/2020
****************************************************** */
/* Pregunta 1 */
-- ELIMINAR TABLAS PARA LAS CORRECIONES.
DROP TABLE EQUIPO;
DROP TABLE JUGADOR;
DROP TABLE ESTADISTICAS;
DROP TABLE PARTIDO:

CREATE TABLE EQUIPO(
Nombre VARCHAR2(20) NOT NULL,
Division VARCHAR2(9) NOT NULL,
Ciudad VARCHAR2(20) NOT NULL,
Conferencia VARCHAR2(4) NOT NULL
-- CONSTRAINT PK_NOMBRE PRIMARY KEY(Nombre),
-- CONSTRAINT CHECK_DIVISION CHECK(),
-- CONSTRAINT CHECK_CONFERENCIA CHECK(Conferencia = 'East' or Conferencia = 'West'),
);

CREATE TABLE JUGADOR(
Codigo NUMBER(3),
Nombre VARCHAR2(30) NOT NULL,
Procedencia VARCHAR2(20),
Altura VARCHAR2(4),
Peso NUMBER(4),
Posicion VARCHAR2(2)
-- CONSTRAINT PK_CODIGO PRIMARY KEY(Codigo),
-- CONSTRAINT CHECK_PESO CHECK(Posicion > 130 and Posicion < 400)
);

CREATE TABLE ESTADISTICAS(
Temporada VARCHAR2(10),
Puntos_por_partido NUMBER(3) DEFAULT(0) CHECK(Puntos_por_partido > 0),
Asistencias_por_partido NUMBER(3) DEFAULT(0) CHECK(Asistencias_por_partido > 0),
Tapones_por_partido NUMBER(3) DEFAULT(0) CHECK(Tapones_por_partido > 0),
Rebotes_por_partido NUMBER(3) DEFAULT(0) CHECK(Rebotes_por_partida > 0)
-- CONSTRAINT PK_TEMPORADA PRIMARY KEY(Temporada)
);


CREATE TABLE PARTIDO(
Codigo NUMBER(3),
Puntos_local NUMBER(3),
Puntos_visitante NUMBER(3),
Equipo_local VARCHAR2(10),
Equipo_visitante VARCHAR2(10),
Temporada VARCHAR2(10)
);

/* *****************************************************
//  INS JOAN D'AUSTRIA
//	CFGS DAW
//	M2: Bases de dades. UF2: Llenguatge SQL
//	PRÀCTICA UF2. FASE 1
//	AUTOR: Albert Campos Gisbert
//	DATA: 20/01/2020
****************************************************** */

DROP TABLE Equipo;
DROP TABLE Jugador;
DROP TABLE Estadisticas;
DROP TABLE Partido;

CREATE TABLE Equipo(
    Nombre VARCHAR2(20) NOT NULL,
    Ciudad VARCHAR2(20) NOT NULL,
    Conferencia CHAR(4) NOT NULL,
    Division VARCHAR2(9) NOT NULL
);

CREATE TABLE Jugador(
    Cod_Jugador NUMBER(20) NOT NULL,
    Nombre VARCHAR2(30) NOT NULL,
    Procedencia VARCHAR2(20),
    Altura VARCHAR2(4),
    Peso NUMBER(3),
    Posicion VARCHAR2(5)
);

CREATE TABLE Estadisticas(
    Cod_Jugador NUMBER(20) NOT NULL,
    Temporada CHAR(5) NOT NULL,
    Puntos_por_partido NUMBER(2,1) DEFAULT(0),
    Asistencias_por_partido NUMBER(2,1) DEFAULT(0),
    Tapones_por_partido NUMBER(2,1) DEFAULT(0),
    Rebotes_por_partido NUMBER(2,1) DEFAULT(0)
);

CREATE TABLE Partido(
    Cod_Partido NUMBER(20) NOT NULL,
    Equipo_local VARCHAR2(20) NOT NULL,
    Equipo_visitante VARCHAR2(20) NOT NULL,
    Puntos_local NUMBER(3) NOT NULL,
    Puntos_visitante NUMBER(3) NOT NULL,
    Temporada CHAR(5) NOT NULL
);

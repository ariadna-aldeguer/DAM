/* *****************************************************
//    INS JOAN D'AUSTRIA
//	CFGS DAW
//	M2: Bases de dades. UF2: Llenguatge SQL
//	PRÀCTICA UF2. FASE 
//	AUTOR: Carlos Gómez
//	DATA: 23/01/2020
****************************************************** */

/* Pregunta 1 */
drop table equipo;
drop table jugador;
drop table estadisticas;
drop table partido;

CREATE TABLE equipo(
	Nombre varchar2(20),
	Ciudad varchar2(20),
	Conferencia char(4),
	Division varchar2(9)
);
CREATE TABLE jugador(
	Codigo number(2),
	Nombre varchar2(20),
	Procedencia varchar2(20),
	Altura char(4),
	Peso number(3),
	Nombre_Equipo varchar2(20),
	Posicion varchar2(5)
);
CREATE TABLE estadisticas(
	Temporada number(2),
	Puntos_por_partido number(2), 
	Asistencias_por_partido number(2),
	Tapones_poe_partido number(2),
	Rebotes_por_partido number(2)
);
CREATE TABLE partido(
	Codigo number(4),
	Equipo_local varchar2(10),
	Equipo_visitante varchar2(20),
	Puntos_local number(3),
	Puntos_visitante number(3),
	Temporada number(2)	
);

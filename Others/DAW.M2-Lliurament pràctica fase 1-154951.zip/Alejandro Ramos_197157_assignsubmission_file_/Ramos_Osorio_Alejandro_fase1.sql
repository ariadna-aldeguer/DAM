/* *****************************************************
//    INS JOAN D'AUSTRIA
//	CFGS DAW
//	M2: Bases de dades. UF2: Llenguatge SQL
//	PRÀCTICA UF2. FASE 
//	AUTOR: Alejandro Ramos Osorio
//	DATA: 23/01/2020
****************************************************** */

/* Pregunta 1 */

CREATE TABLE EQUIPO (
    Nombre VARCHAR2(20) NOT NULL,
    Ciudad VARCHAR2(20) NOT NULL,
    Conferencia VARCHAR2(4) NOT NULL,
    Division VARCHAR2(9) NOT NULL
);

CREATE TABLE JUGADOR (
    Codigo NUMBER(4) NOT NULL,
    Nombre VARCHAR2(30),
    Procedencia VARCHAR2(20),
    Altura VARCHAR2(4),
    Peso NUMBER(3),
    Posicion VARCHAR2(2),
    Nombre_Equipo VARCHAR2(20)
);

CREATE TABLE ESTADISTICAS (
    Codigo NUMBER(4) NOT NULL,
    Temporada CHAR(5),
    Puntos_por_partido NUMBER(4,1),
    Asistencias_por_partido NUMBER(4,1),
    Tapones_por_partido NUMBER(4,1),
    Rebotes_por_partido NUMBER(4,1)
);

CREATE TABLE PARTIDO (
    Codigo,
    Equipo_local VARCHAR2(20) NOT NULL,
    Equipo_visitante VARCHAR2(20) NOT NULL,
    Puntos_local NUMBER(3) NOT NULL,
    Puntos_visitante NUMBER(3) NOT NULL,
    Temporada CHAR(5) NOT NULL
);
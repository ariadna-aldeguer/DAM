CREATE TABLE EQUIPO (
    Ciudad varchar(20) NOT NULL,
    Nombre varchar(20) NOT NULL,
    Conferencia varchar(4) constraint ch_con1 Check (Conferencia  like 'East' or Conferencia  like 'West' ),
    Division varchar(9) constraint ch_con2 check (Division like 'Atlantic' or Division like 'Central' or Division like 'NorthWest' or Division like 'Pacific' or Division like 'SouthWest')
);

CREATE TABLE JUGADOR (
    Codigo INT,
    Nombre varchar(30) NOT NULL,
    Procedencia varchar(20),
    Altura varchar(4) constraint ch_con3 Check (Altura like '[0-9]{1}-[0-9]{2}'),
    Peso INT constraint ch_con4 check (Peso between 130 and 400),
Altura varchar(4) constraint ch_con5 Check (Altura like '[GFC]{1,3}')
);

CREATE TABLE ESTADISTICAS (
    Codigo INT,
    Temporada varchar(5) ch_con6 Check (Altura like '[0-9]{2}\/[0-9]{2}'),
    Puntos_por_partido INT(6,1) constraint ch_con7 (Puntos_por_partido >0),
    Asistencias_por_partido decimal default 0,
    Tapones_por_partido decimal(6,1) default 0 constraint ch_con8 (Tapones_por_partido >0),
    Rebotes_por_partido decimal(6,1) default 0 constraint ch_con9 (Tapones_por_partido >0)
);

CREATE TABLE PARTIDO(
    Codigo INT,
    Equipo_local INT NOT NULL,
    Equipo_visitante decimal default 0,
    Puntos_local INT,
    Punto_visitante INT,
    Temporada varchar(5) ch_con9 Check (Altura like '[0-9]{2}\/[0-9]{2}')
);




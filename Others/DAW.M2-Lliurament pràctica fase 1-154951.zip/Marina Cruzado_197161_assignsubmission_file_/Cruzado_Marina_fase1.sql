/* *****************************************************
//    INS JOAN D'AUSTRIA
//	CFGS DAW
//	M2: Bases de dades. UF2: Llenguatge SQL
//	PRÀCTICA UF2. FASE 
//	AUTOR: Marina Cruzado
//	DATA: 23/01/20
****************************************************** */

/* Pregunta 1 */

/* Drop table */
DROP TABLE equipo;
DROP TABLE jugador;
DROP TABLE estadisticas;
DROP TABLE partido;

/* Taules */
CREATE TABLE equipo (
    nombre varchar2(20),
    ciudad varchar2(20) not null,
    conferencia char(4) not null,
    division varchar2(9) not null
);

CREATE TABLE jugador (
    codigo number(5),
    nombre varchar2(30) not null,
    procedencia varchar2(20),
    altura char(4),
    peso number(3),
    nombre_equipo varchar2(20) not null,
    posicion varchar2(5)
);

CREATE TABLE estadisticas (
    codigo number(5),
    temporada char(5),
    puntos_por_partido number(3,1) default 0,
    asistencias_por_partido number(3,1) default 0,
    tapones_por_partido number(3,1) default 0,
    rebotes_por_partido number(3,1) default 0
);

CREATE TABLE partido (
    codigo number(5),
    equipo_local varchar2(20) not null,
    equipo_visitante varchar2(20) not null,
    puntos_local number(3),
    puntos_visitante number(3),
    temporada char(5) not null
);

#!bin/bash

if [ $USER = 'DAM1' ]
then
	echo "Hola"
else
	echo "Adéu"
fi

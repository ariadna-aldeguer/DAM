#!bin/bash

DATA=$(date +%d-%m-%y)
RUTA=/home/ari/scripts
NOM=Ariadna

tar -czfpf $DATA$NOM$USER.tar.gz *.sh


#!bin/bash

read num1
read num2

mitjana=$((num1*num2/2))

echo $mitjana

#!bin/bash

read nomCarpeta
read nomFitxer

cd

mkdir $nomCarpeta
touch $nomFitxer

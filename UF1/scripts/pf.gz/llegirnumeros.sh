#!bin/bash

read numero1
read numero2

multiplicacio=$((numero1*numero2))

echo $multiplicacio

#!/bin/bash

nom="Ariadna"

echo "Hola" $nom


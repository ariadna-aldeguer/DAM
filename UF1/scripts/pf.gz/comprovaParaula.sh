#!bin/bash

read paraula

if [ $paraula = "hola" ]
then	echo "Correcte"
else 	echo "mal"
fi

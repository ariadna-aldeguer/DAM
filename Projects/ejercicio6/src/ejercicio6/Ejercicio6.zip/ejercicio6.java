package ejercicio6;

public class ejercicio6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

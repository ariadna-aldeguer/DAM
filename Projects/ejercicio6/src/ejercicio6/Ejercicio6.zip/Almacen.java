package ejercicio6;

import java.util.ArrayList;

public class Almacen {
	
	private ArrayList<ProductoEnStock> productoEnStock;
	
	public Almacen () {
		this.productoEnStock = new ArrayList <ProductoEnStock>();
	}

	public Almacen(ArrayList<ProductoEnStock> productoEnStock) {
		this.productoEnStock = productoEnStock;
	}

}

import java.util.ArrayList;

public class Catalogo {
	private ArrayList<Producto> productos;
	
	public Catalogo() {
		this.productos = new ArrayList<Producto>();
	}
	
}


public abstract class Privilegio {
	
	public abstract void aplica(Pedido pedido);
}

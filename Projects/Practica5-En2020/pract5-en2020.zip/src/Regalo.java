
public class Regalo extends Privilegio{

	@Override
	public void aplica(Pedido pedido) {
		// TODO Auto-generated method stub
		
	}
	
}

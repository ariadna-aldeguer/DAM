
public class InterfazUsuario {
	private Controlador controlador;

	public InterfazUsuario() {
	}
	public InterfazUsuario(Controlador controlador) {
		this.controlador = controlador;
	}
}

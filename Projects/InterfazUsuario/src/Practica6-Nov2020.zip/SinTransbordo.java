
public class SinTransbordo extends BuscadorRutas{

	@Override
	public Ruta buscaRuta(String npIni, String npFin) {
		// TODO Auto-generated method stub
		return null;
	}
	
}

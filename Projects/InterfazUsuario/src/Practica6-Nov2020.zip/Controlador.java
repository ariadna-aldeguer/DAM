
public class Controlador {
	private RedTransporte red;
	private BuscadorRutas buscador;
	
	
	public Controlador() {
	}
	
	public Controlador(RedTransporte red, BuscadorRutas buscador) {
		this.red = red;
		this.buscador = buscador;
	}
	
	
}

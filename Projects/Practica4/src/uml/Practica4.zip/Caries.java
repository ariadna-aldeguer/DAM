package uml;

public class Caries extends LineaTratamiento{
	private int numDientesAfectados;
}

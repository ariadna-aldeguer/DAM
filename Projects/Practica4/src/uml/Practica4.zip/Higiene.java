package uml;

public class Higiene extends LineaTratamiento {

}

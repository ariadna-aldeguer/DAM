
public class Persona extends Cliente{
    private String nombre;
    private String apellidos;
	
    public Persona() {

	}
    public Persona(String nombre, String apellidos) {
		this.nombre = nombre;
		this.apellidos = apellidos;
	}
    
    
}

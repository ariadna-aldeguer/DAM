
public class InterficieUsuario {
    private Controlador controlador;

    public InterficieUsuario() {
	}
	public InterficieUsuario(Controlador controlador) {
		this.controlador = controlador;
	}
    
}

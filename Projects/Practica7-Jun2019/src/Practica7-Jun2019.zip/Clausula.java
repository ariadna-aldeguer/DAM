
public class Clausula {
	private String texto;
	
	public Clausula() {
		this.texto = "";
	}
	public Clausula(String texto) {
		this.texto = texto;
	}
	
	
}

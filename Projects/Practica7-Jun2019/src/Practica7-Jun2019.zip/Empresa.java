
public class Empresa extends Cliente{
    private String nombreComercial;

    public Empresa() {
	}
	public Empresa(String nombreComercial) {
		this.nombreComercial = nombreComercial;
	}
    
    
}

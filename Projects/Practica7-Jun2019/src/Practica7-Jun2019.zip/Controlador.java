import java.util.ArrayList;

public class Controlador {
    ArrayList<Cliente> clientes;
    ArrayList<Seguro> seguros;
    
    public Controlador() {
    	this.clientes = new ArrayList<Cliente>();
        this.seguros = new ArrayList<Seguro>();
    }
}

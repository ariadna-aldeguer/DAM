package ejercicio5;

public class Persona {

	protected String Nombre;
	protected String Nif;
	
	
	// POR DEFECTO
	public Persona() {
		String Nombre = "";
		String NIF="";
		
	}

	//FULL
	public Persona(String nombre, String nif) {
		Nombre = nombre;
		Nif = nif;
	}
	
	
	
	
	
	
}

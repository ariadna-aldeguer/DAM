package ejercicio5;

public class Tecnico extends Persona {

		private String codigoLicencia;
		
		// POR DEFECTO
		public Tecnico() {
			this.codigoLicencia = "";
		}
		
		// FULL
		public Tecnico(String codigoLicencia) {
			this.codigoLicencia = codigoLicencia;
		}
		
		
}

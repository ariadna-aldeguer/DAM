package intro001;

public interface Producto {

// ----------------------------------------- PROBLEMA 8 ----------------------------------------- |
	
	// (8.A) Crea un interfaz Producto que defina los siguientes métodos
	
	public float getPrecio();
	public String getDescripcion();
	
	// (8.C) Intenta crear un atributo en la interfaz Producto:
	
	// private int numProductos;
		
	public int numProductos = 5;
	
	// (8.D) Intenta implementar un método en la interfaz Producto
	
	/*
		public String getDescripcion() {
			return "";
		}
	*/ 
	
	// (8.E) Intenta crear un constructor en la interfaz Producto:
	
	/*
	
		public Producto() {
			
		}
		
	*/
}

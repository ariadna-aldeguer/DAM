/*
package intro002;

import intro001.Vehiculo;

 ----------------------------------------- PROBLEMA 1 -----------------------------------------

 (1.D) Copia el fichero Main del apartado b) en otro package, el mismo donde se ha creado coche 

public class Main {

	public static void main(String[] args) {
		
		Vehiculo v1 = new Vehiculo();
		
		// Constructor
		
		v1.color = "amarillo";
		v1.caballos = 180;
		v1.marca = "Nissan";
		v1.modelo = "Primera";

	}

}
*/

/*

package intro002;

----------------------------------------- PROBLEMA 1 ----------------------------------------- 

 (1.C) Crea la clase Coche que hereda de la clase Vehiculo pero en otro paquete. 

import intro001.Vehiculo;

public class Coche extends Vehiculo{
	
	// Constructor
	
	public Coche() {
		this.marca="";
		this.modelo="";
		
	}
	
}
*/
